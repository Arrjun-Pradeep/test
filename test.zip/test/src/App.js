import "./App.css";
/*global chrome*/

function App() {
  // const popup = async () => {
  //   var url = "chrome-extension://felkkgndpgljchepliiibanoccmhlclf/index.html";
  //   // window.open(url);
  //   window.open(
  //     "url",
  //     "_blank",
  //     "height=400, width=550, status=no, toolbar=no, menubar=no, location=no, addressbar=no, top=200, left=300"
  //   );
  //   // window.open("url", "_blank", );

  //   // // window.popup(url, '', 'toolbar=no')

  //   // chrome.runtime.sendMessage("felkkgndpgljchepliiibanoccmhlclf", '1.0', response => {
  //   //   console.log("RESPONSE", response);
  //   // })
  // };

  return (
    <div className="container">
      <button className="button button2 trigger">POPUP</button>
      <button className="button button2">ETHEREUM OBJECT IDENTIFY</button>
    </div>
  );
}

export default App;
